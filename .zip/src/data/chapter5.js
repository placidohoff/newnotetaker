export default {
    title: 'Chapter 5, The Extended Entitylationship Model',
    notes: [],
    terms: [
        {
            meta: 'vocab',
            term: 'Extended Relationship Model',
            definition: `The added semantic constructs to the ER model.`
        },
        {
            meta: 'note',
            note: `"Entity Supertype" is a generic type that is parent to more "Entity Subtypes" which are more specific`
        },
        {
            meta: 'note',
            note: `To classify a Subtype, there must be one or more attribbutes that are unique to that kind of instance.`

        },
        {
            meta: 'note',
            note: `The relationship depicted in a specialization hierachy is usually described as a "is-a" relationship `

        },
        {
            meta: 'img',
            note: `Specialization Heirachy`,
            src: `https://www.linkpicture.com/q/16460913628215479477849695491410-min.jpg`
        },
        {
            meta: 'note',
            note: `All entity subtypes inherit their primary key attribute from their supertype`
        },
        {
            meta: 'list',
            note: `Subtype entities inherit all of the attributes and relationships from all of its upper-level supertypes`,
            list: [
                {
                    meta: 'note',
                    note: `However, subtypes can have relationships of their pwn that their supertype does not have`
                }
            ]
        },
        {
            meta: 'img',
            note: '"Subtype Discriminator" determines which attribute defines the subtype from the supertype..',
            src: 'https://www.linkpicture.com/q/16461133912654706707730216893976-min.jpg'
        },
        {
            meta: 'vocab',
            term: 'Disjoint/Nonoverlapping',
            definition: "When a subtype can only be one a member of only one subtype and not multiple",
            notes: [
                {
                    meta: 'note',
                    note: 'denoted with a "D" in the ERD',
                }
            ]
        },
        {
            meta: 'vocab',
            term: 'Overlapping Subtypes',
            definition: "When a subtype is permitted to have to be a member of multiple subtypes",
            notes: [
                {
                    meta: 'note',
                    note: 'denoted with an "O" in the ERD',
                }
            ]

        },
        {
            meta: 'list',
            term: 'Completeness Constraint',
            definition: 'Specifies whether the entity supertype occurence must also be a member of at least one subtype. Can be "Partial" or "Total"',
            list: [
                {
                    meta: 'vocab',
                    term: 'Partial Completeness',
                    definition: 'Not every supertype occurence has to be a member of a subtype',
                    examples: [
                        {
                            meta: 'img',
                            note: 'Denoted as a single line in the ERD',
                            img: 'NULL'
                        }
                    ]
                },
                {
                    meta: 'vocab',
                    term: 'Total Completeness',
                    definition: 'The supertype has to be a member of at least one subtype',
                    examples: [
                        {
                            meta: 'img',
                            note: 'Denoted as a double line in the ERD',
                            img: 'NULL'
                        }
                    ]
                },
            ]
        },
        {
            meta: 'list',
            note: 'There are various approaches to develop entity supertypes and subtypes. Most common are "Specialization" and "Generalization"',
            list: [
                {
                    meta: 'vocab',
                    term: 'Specialization',
                    definition: 'Top-down approach to developing subtypes from  supertype. We further categorize/specialize subtypes from the parent supertype'
                },
                {
                    meta: 'vocab',
                    term: 'Generalization',
                    definition: 'Bottom-up approach to developing a supertype from subtypes based on common/general shared chaacteristics of the subtypes.'
                },
            ]
        },
        {
            meta: 'vocab',
            term: 'Entity Cluster',
            definition: 'An "abstract" entity used to represent an instance of multiple entity relationships as one abstract instance for the purpose of simplifying the ERD to make it more readable.',
            notes: [
                {
                    meta: 'note',
                    note: 'It is a genral rule in the ERD to avoid dispkaying attributes of any entities when entity clusters are used in the same ERD.'
                }
            ]

        },
        {
            meta: 'list',
            note: 'There are some guidelines to developing a Primary Key',
            list: [
                {
                    meta: 'note',
                    note: 'The function of the primary key is to guarantee entity integrity, not to "describe" the entity'
                },
                {
                    meta: 'note',
                    note: 'Primary keys should have minimum attributes but composite keys should still be used "as identifyers of weak entities that are dependent on attributes of the parent" '
                },
            ]
        }

    ]
}