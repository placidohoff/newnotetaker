export default {
    title: 'Chapter 4, Entity Relationship Modeling',
    notes: [],
    terms: [
        {
            meta: 'note',
            note: `The ERD represents the conceptual database as viewed by the end user. Depicts the main components: entities, attributes, and relationships`
        },
        {
            meta: 'list',
            note: `Because of emphasis on design and implementation, the Crow's Foot and UML class diagram notations are used primarily.`,
            list: [
                {
                    meta: 'note', note: 'Chen Notation: favors conceptual modeling'
                },
                {
                    meta: 'note', note: `Crow's Foot Notation favors a more implementation-oriented approach`
                },
                {
                    meta: 'note', note: `UML notation can be used for both conceptual and implementation modeling`
                },
            ]
        },
        {
            meta: 'vocab',
            term: 'Entities',
            definition: `In ERM, this refers to the "entity set", or the entire table, not a row.`,
            notes: [
                { meta: 'note', note: `ERM refers to a table row as an "entity instance"` },
                { meta: 'note', note: `Represented as a Square` },
            ]
        },
        {
            meta: 'vocab',
            term: 'Attributes',
            definition: `Characteristics of entities.`,
            notes: [
                { meta: 'note', note: `Represented as a circle in the Chen Notation.` },
                { meta: 'note', note: `In Crow's Foot Notation, attributes are are writtin within the Square/Entity`, notes: [{ meta: 'note', note: 'A "required attribute" is represented by bold text' }] },
            ]
        },
        {
            meta: 'vocab',
            term: 'Domain',
            definition: `A possible set of values for a gien attribute`
        },
        {
            meta: 'vocab',
            term: 'Identifiers (Primary Keys)',
            definition: `Primary key. In relational models these are mapped to a table. In ERM it is underlined.`,
            notes: [
                {
                    meta: 'img',
                    note: 'test',
                    src: `https://www.linkpicture.com/q/2022-01-08.png`
                },
            ]
        },
        {
            meta: 'vocab',
            term: 'Composite Identifier',
            definition: 'A primary key composed of more than one attribute.'
        },
        {
            meta: 'vocab',
            term: 'Composite Attribute',
            definition: 'An attribute that can be further subdivided to yield additional attributes.',
            examples: [{ meta: 'note', note: `ADDRESS can be subdivided into street, city, and zip code` }]
        },
        {
            meta: 'vocab',
            term: 'Single-Valued Attribute',
            definition: 'An attribute that can only have one single value.',
            examples: [
                { meta: 'note', note: `A person can only have one social security number` },
                { meta: 'note', note: `A single valued attribute is not neccessarily a simple attribute. (A part's serial number is single valued but it is a composite attribute because it can be sub-divided into region, plant, shift, and part number. (SE-08-02-189935))` },
            ]
        },
        {
            meta: 'vocab',
            term: 'Multivalued Attributes',
            definition: 'Attributes that can have many values.',
            notes: [
                {
                    meta: 'img',
                    note: `In Chen ERM, these attributes are shown with a double line connecting the attribute and entity. The Crow's foot notation does not identify multivalued attributes`,
                    src: 'https://www.linkpicture.com/q/Compress_20220130_141041_1354.jpg'
                }
            ],
            examples: [{ meta: 'note', note: 'A person can have several degrees, car can have many colors' }],

        },
        {
            meta: 'list',
            note: `The conceptual model/plan can handle M:N, but we should not actually implement it in our RDBMS tables. Each attribute in a table must be one value, therfore the designer must decide on two possible solutions:`,
            list: [
                {
                    meta: 'note',
                    note: `Option 1: Create several new attributes for the entity. One for each component of the multivalued attribute`,
                    examples: [
                        {
                            meta: 'img',
                            note: `Car has multiple colors, so we divide the colors into their own categories`,
                            src: `https://www.linkpicture.com/q/Compress_20220130_143247_7206.jpg`
                        }
                    ]
                },
                {
                    meta: 'note',
                    note: `Option 2: Create a new entity with it's attributes composed of the multivalued attribute's components. Then relate this new entity to our original entity with a foreign key, and a 1:M relationship`,
                    examples: [
                        {
                            meta: 'img',
                            note: `CAR has a 1:M relation to CAR_COLOR`,
                            src: `https://www.linkpicture.com/q/Compress_20220130_144532_2734.jpg`
                        }
                    ]
                }
            ]
        },
        {
            meta: 'vocab',
            term: 'Derived Attribute',
            definition: `An attribute whose values are calculated (derived) from other attributes. This value is not physically stored in the database but instead derived using an algorithm`,
            notes: [
                {
                    meta: 'note',
                    note: `An advantage is it saves data access time, but a disadvantage is that it requires constant maintenance to ensure derived value is current if any values used in the calculation change.`
                }
            ],
            examples: [
                {
                    meta: 'note',
                    note: 'EMP_AGE is found by computing current date - EMP_DOB'
                },
                {
                    meta: 'note',
                    note: 'Total cost is quantity x unit price'
                },
                {
                    meta: 'img',
                    note: `Depicted with a dashed line to the attribute`,
                    src: 'https://www.linkpicture.com/q/Compress_20220130_150345_5770.jpg'
                }
            ]
        },
        {
            meta: 'list',
            note: 'Relationships are an association between entities.',
            list: [
                {
                    meta: 'vocab',
                    term: 'Participants',
                    definition: 'Entities in a relationship.'
                },
                {
                    meta: 'img',
                    note: 'Conectivity describes the relationship classification and Cardinality expresses the minimum number of entity occurances of each of the related entities. (Defined by business rules)',
                    src: 'https://www.linkpicture.com/q/Compress_20220130_154744_4170.jpg'
                },
                {
                    meta: 'vocab',
                    term: 'Existence-dependent',
                    definition: 'An entity that can only exist when it is associated with another related entity occurance',
                    examples: [
                        {
                            meta: 'note',
                            note: 'An entity is existence-dependent if it has a foreign key that cannot be NULL'
                        },
                        {
                            meta: 'note',
                            note: `EMPLOYEE claims DEPENDENT: DEPENDENT is existece-dependent on the EMPLOYEE entity as in its table there MUST be a value in the EMPLOYEE foreign key `
                        },
                    ]
                },
                {
                    meta: 'vocab',
                    term: 'Existence-independent',
                    definition: `An entity that can exist apart fron all of its related attributes`
                },
                {
                    meta: 'list',
                    note: `Relationship strength is based on how the primary key of a related entity is defined.`,
                    list: [
                        {
                            meta: 'vocab',
                            term: `Weak (Non-Identifying) Relationship`,
                            definition: `The primary key of the related/child entity does not contain a primary key parent entity as its own.`,
                            examples: [
                                {
                                    meta: 'img',
                                    note: 'Key of the parent entity is only a foreign key in the child',
                                    src: 'https://www.linkpicture.com/q/Compress_20220130_172444_4367.jpg'
                                },
                                {
                                    meta: 'img',
                                    note: 'Indicated with a dotted line in Crow Notation.',
                                    src: 'https://www.linkpicture.com/q/Compress_20220130_173253_3482.jpg'
                                },
                            ]

                        },
                        {
                            meta: 'vocab',
                            term: `Strong (Identifying) Relationship`,
                            definition: `The primary key of the related entity contains a primary key of the parent also as its own.`,
                            examples: [
                                {
                                    meta: 'img',
                                    note: 'Example 1',
                                    src: 'https://www.linkpicture.com/q/Compress_20220130_173903_3234.jpg'
                                },
                                {
                                    meta: 'img',
                                    note: `Indicated with a solid line in Crow's Foot Notation`,
                                    src: 'https://www.linkpicture.com/q/Compress_20220130_174300_0546.jpg'
                                },
                            ]
                        }
                    ]
                }
            ]
        },
        {
            meta: 'vocab',
            term: 'Weak Entities',
            definition: `Entity that is existence-dependent on the other / has a primary key that is partially or totally derived from the parent`,
            examples: [
                {
                    meta: 'img',
                    note: 'examples',
                    src: 'https://www.linkpicture.com/q/Compress_20220130_181122_2101.jpg'
                },
            ]
        },
        {
            meta: 'vocab',
            term: 'Optional Relationship Participation',
            definition: `Indicates that one entity occurence does not REQUIRE a corresponding entity occurence in a particular relationship.`,
            notes: [
                {
                    meta: 'note',
                    note: `In Crow's Foot, an optional participation is indicated with a 'O' (small circle) on the side of the optional entity`
                }
            ],
            examples: [
                {
                    meta: 'note',
                    note: `Some courses do not generate a class, therefore the CLASS entity is considered to be optional to the COURSE entity.`
                }
            ]
        },
        {
            meta: 'vocab',
            term: 'Mandatory Participation',
            definition: `One entity occurence REQUIRES a corresponding entity iccyrence.`,
            notes: [
                {
                    meta: 'note',
                    note: `Is indicated with no small circles in the relational graphic line`
                }
            ]
        },
        {
            meta: 'list',
            note: 'Relationship Degree: Indicates the number of entities or participants associated with a relationship. Can be catorgorized as "Unary", "Binary", or "Ternary"',
            list: [
                {
                    meta: 'vocab',
                    term: 'Unary Relationship',
                    definition: 'Relationship maintained within a single entity',
                    notes: [
                        {
                            meta: 'vocab',
                            term: 'Recursive Relationship',
                            definition: `Relationship that exist between occurrences of the same entity set.`,
                            examples: [
                                {
                                    meta: 'note',
                                    note: 'EMPLOYEE manages many EMPLOYEEs'
                                },
                                {
                                    meta: 'note',
                                    note: 'COURSE may have many other COURSEs as prerequisites'
                                },
                                {
                                    meta: 'img',
                                    note: 'diagram',
                                    src: 'https://www.linkpicture.com/q/Compress_20220130_201455_5591.jpg'
                                }
                            ],

                        }
                    ]
                },
                {
                    meta: 'vocab',
                    term: 'Binary Relationship',
                    definition: 'When two entities are associated'
                },
                {
                    meta: 'vocab',
                    term: 'Ternary Relationship',
                    definition: 'When three entities are associated'
                },
            ]
        },
        {
            meta: 'vocab',
            term: 'Associative (Composite) Entities',
            definition: `Implementing the M:N relationship requires the use of an additional entity; an "Associative Entity", or "Bridge Entity"`,
            notes: [
                {
                    meta: 'note',
                    note: `This entity has a 1:M relationship with the two parent entities. Also has additional attributes of its own. `
                },
                {
                    meta: 'img',
                    note: 'M:N ERM Between Student and Class',
                    src: `https://www.linkpicture.com/q/Compress_20220130_204313_3774.jpg`
                },
                {
                    meta: 'img',
                    note: 'Composite Entity used between Student and Class',
                    src: `https://www.linkpicture.com/q/Compress_20220130_204645_5200.jpg`
                },
                {
                    meta: 'img',
                    note: `Converted M:N relationship into two 1:M relationships using tables`,
                    src: `https://www.linkpicture.com/q/Compress_20220130_205311_1194.jpg`
                },
            ]
        },
        {
            meta: 'list',
            note: `Developing an ER Diagram is an "iterative" process rather than linear one`,
            list: [
                {
                    meta: 'note',
                    note: `1.) Create a detailed narrative of the organization's description of operations`
                },
                {
                    meta: 'note',
                    note: `2.) Identify the business rules based on the description of operations`
                },
                {
                    meta: 'note',
                    note: `3.) Identify the main entities and relationships of the business rules`
                },
                {
                    meta: 'note',
                    note: `4.) Devlop the initial ERD`
                },
                {
                    meta: 'note',
                    note: `5.) Identify the attributes and primary keys that adequateky describe the entities`
                },
                {
                    meta: 'note',
                    note: `6.) Revise and review the ERD`
                },
            ]
        }
    ]
}